زرپالس — نسخه HTML اینفوگرافیک

فایل اصلی: index.html
حالت بدون انیمیشن برای خروجی/اسکرین‌شات: index.html?static=1
عرض طراحی: 960px

فونت پیشنهادی: Vazirmatn (از Google Fonts بارگذاری می‌شود) با fallback روی Segoe UI و Tahoma.
هیچ فایل فونتی داخل بسته قرار داده نشده است.
