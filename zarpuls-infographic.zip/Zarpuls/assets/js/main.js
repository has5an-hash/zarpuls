(()=>{
  'use strict';
  const body=document.body;
  const params=new URLSearchParams(location.search);
  const staticMode=params.get('static')==='1';

  const revealGroups=[
    '.section','.final-section',
    '.four-grid article','.source-card','.formula-card','.product-gallery figure',
    '.market-row','.control-card','.dash-metrics article','.compat-grid span'
  ];
  document.querySelectorAll(revealGroups.join(',')).forEach((el,i)=>{
    el.setAttribute('data-reveal','');
    el.style.setProperty('--reveal-delay',`${Math.min((i%6)*55,275)}ms`);
  });

  if(staticMode){
    body.classList.add('static');
    document.querySelectorAll('[data-reveal]').forEach(el=>el.classList.add('is-visible'));
  }else{
    body.classList.add('js-animate');
    const io=new IntersectionObserver((entries)=>{
      entries.forEach((entry)=>{
        if(entry.isIntersecting){
          entry.target.classList.add('is-visible');
          io.unobserve(entry.target);
        }
      });
    },{threshold:.1,rootMargin:'0px 0px -5% 0px'});
    document.querySelectorAll('[data-reveal]').forEach(el=>io.observe(el));
  }

  const timer=document.querySelector('[data-timer]');
  if(timer && !staticMode){
    let left=Number(timer.dataset.timer||299);
    const fa=(v)=>String(v).replace(/\d/g,d=>'۰۱۲۳۴۵۶۷۸۹'[d]);
    const draw=()=>{
      const m=Math.floor(left/60),s=left%60;
      timer.textContent=fa(String(m).padStart(2,'0')+':'+String(s).padStart(2,'0'));
    };
    draw();
    setInterval(()=>{left=left<=0?299:left-1;draw();},1000);
  }

  // Subtle pointer parallax only on devices that actually have a mouse.
  if(matchMedia('(hover:hover) and (pointer:fine)').matches && !staticMode){
    document.querySelectorAll('.brand-mark,.dash-logo,.final-brand img,.engine-face').forEach((el)=>{
      el.addEventListener('pointermove',(e)=>{
        const r=el.getBoundingClientRect();
        const x=(e.clientX-r.left)/r.width-.5;
        const y=(e.clientY-r.top)/r.height-.5;
        el.style.setProperty('--px',`${x*4}px`);
        el.style.setProperty('--py',`${y*4}px`);
      });
      el.addEventListener('pointerleave',()=>{
        el.style.setProperty('--px','0px');
        el.style.setProperty('--py','0px');
      });
    });
  }
})();
